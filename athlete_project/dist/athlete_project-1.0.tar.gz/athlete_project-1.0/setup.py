from distutils.core import setup
"""importing setup function from distribution utilities"""
setup(
	name="athlete_project",
	version="1.0",
	py_modules=["athletelist"],
	author="vidhya",
	author_email="vidhu.chel@gmail.com",
	description="A class with two function to understand the basics of class"

)
